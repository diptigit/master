package com.hcl.service.imp;

import java.util.ArrayList;
import java.util.List;

import com.hcl.model.User;
import com.hcl.service.UserService;

public class UserServiceImp implements UserService{

	@Override
	public List<User> getAllUsers() {
		List<User> list=new ArrayList<User>();
		User user=new User();
		User user1=new User();
		user.setId(100);
		user.setName("Dipti");
		user.setProfession("QA");		
		list.add(user);
		user1.setId(101);
		user1.setName("Pampa");
		user1.setProfession("SE");
		list.add(user1);
		return list;
	}

}
