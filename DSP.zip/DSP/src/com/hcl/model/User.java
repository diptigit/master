package com.hcl.model;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement 
public class User {
	private int id; 
	   public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getProfession() {
		return profession;
	}
	public void setProfession(String profession) {
		this.profession = profession;
	}
	private String name; 
	   private String profession; 
	
	
	   
	   @Override
	    public String toString() {
	        return "JsonExample [id=" + id + ", name=" + name +  ", profession=" + profession +"]";
	    }

}
