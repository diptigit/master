package com.hcl.controller;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.hcl.dao.UserDao;
import com.hcl.dao.imp.UserDaoImp;
import com.hcl.model.User;


@Path("/hclTechnologies")
public class TestController {
	UserDao userDao = new UserDaoImp();  
	   @GET 
	   @Path("/getUsers") 
	   @Produces(MediaType.APPLICATION_JSON) 
	   public List<User> getUsers(){   
	      return userDao.getAllUsers(); 
	   }  
	   
	/*  @POST
	   @Path("/users")
	   @Produces(MediaType.APPLICATION_JSON)
	   @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	   public String createUser(JsonObject inputJsonObj,
	      @Context HttpServletResponse servletResponse) throws IOException{		  
		
			      return userDao.saveUsers(User); 
			   }
	     // User user = new User(id, name, profession);
	      int result =1;// userDao.addUser(user);
	      if(result == 1){
	         return "SUCCESS";
	      }
	      return "FAILURE_RESULT";
	   }
*/


}
