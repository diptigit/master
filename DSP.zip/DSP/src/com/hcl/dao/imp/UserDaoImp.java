package com.hcl.dao.imp;

import java.util.List;


import com.hcl.dao.UserDao;
import com.hcl.model.User;
import com.hcl.service.UserService;
import com.hcl.service.imp.UserServiceImp;

public class UserDaoImp  implements UserDao{

	
	@Override
	public List<User> getAllUsers() {
		UserService userService=new UserServiceImp();
		return userService.getAllUsers();
	}




}
