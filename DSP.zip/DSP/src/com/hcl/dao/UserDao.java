package com.hcl.dao;

import java.util.List;

import com.hcl.model.User;

public interface UserDao {
	public List<User> getAllUsers();

	
}
